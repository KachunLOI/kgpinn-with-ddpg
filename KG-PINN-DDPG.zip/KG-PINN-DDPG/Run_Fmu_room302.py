
# 如何在FMPy中设置输入变量（fmpy.simulate_fmu） 
# https://www.soinside.com/question/SKCcCME4Yo25fqtNGcCdV

from fmpy import * 
from fmpy import extract, read_model_description, instantiate_fmu, simulate_fmu, plot_result

fmu_filename1 = 'DC_room302.fmu'

# extract the FMU to a temporary directory
unzipdir1 = extract(fmu_filename1)

# read the model description
model_description1 = read_model_description(unzipdir1)

# instantiate the FMU beforehand, so we can keep it alive
fmu_instance1 = instantiate_fmu(unzipdir=unzipdir1, model_description=model_description1)

print('instantiate_fmu')

result = simulate_fmu(filename=unzipdir1, 
                      model_description=model_description1,
                      fmu_instance=fmu_instance1,
                      stop_time = 100, 
                      output_interval = 10) # simulate the FMU 

fmu_instance1_1 = instantiate_fmu(unzipdir=unzipdir1, model_description=model_description1)

result = simulate_fmu(filename=unzipdir1,
                      model_description=model_description1,
                      fmu_instance=fmu_instance1_1,
                      stop_time = 100, 
                      output_interval = 10) # simulate the FMU 


fmu_filename2 = 'DC_room302.fmu'

# extract the FMU to a temporary directory
unzipdir2 = extract(fmu_filename2)

# read the model description
model_description2 = read_model_description(unzipdir2)

# instantiate the FMU beforehand, so we can keep it alive
fmu_instance2 = instantiate_fmu(unzipdir=unzipdir2, model_description=model_description2)

result = simulate_fmu(filename=unzipdir2,
                      model_description=model_description2,
                      fmu_instance=fmu_instance2,
                      stop_time = 1900, 
                      output_interval = 10) # simulate the FMU
print(unzipdir1)

print(unzipdir2)


'''
fmu = 'DC_room302_1.fmu' 

dump(fmu) # get information

result = simulate_fmu(fmu, stop_time = 1900, output_interval = 10) # simulate the FMU 

fmu1 = 'DC_room302_2.fmu' 

dump(fmu1) # get information

result = simulate_fmu(fmu1, stop_time = 1900, output_interval = 10) # simulate the FMU 
'''
#print(result) ## 


# Retrieve the result for the variables
#out1_res = result['realOut1']
#out2_res = result['realOut2']


#print(out1_res)
#print('#############################################################')
#print(out2_res)


#from fmpy.util import plot_result # import the plot function 

#plot_result(result)    # plot the result