from setuptools import setup
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

setup(
    name='rnngat_dc',
    ext_modules=[
        CUDAExtension('RNNGAT_DC', [
            'src/rnngat_dc.cpp',
            'src/rnngat_dc_cuda.cu',
        ])
    ],
    cmdclass={
        'build_ext': BuildExtension
    }
) 