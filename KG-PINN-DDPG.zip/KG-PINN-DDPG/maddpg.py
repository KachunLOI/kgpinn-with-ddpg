import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np

class Actor(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Actor, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim),
            nn.Tanh()
        )
    
    def forward(self, x):
        return self.net(x)

class Critic(nn.Module):
    def __init__(self, state_dim, action_dim):
        super(Critic, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(state_dim + action_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 1)
        )
    
    def forward(self, state, action):
        x = torch.cat([state, action], dim=1)
        return self.net(x)

class MADDPG:
    def __init__(self, n_agents, state_dims, action_dims):
        self.n_agents = n_agents
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 为每个智能体创建actor和critic网络
        self.actors = []
        self.critics = []
        self.actor_targets = []
        self.critic_targets = []
        self.actor_optimizers = []
        self.critic_optimizers = []
        
        for i in range(n_agents):
            actor = Actor(state_dims[i], action_dims[i]).to(self.device)
            critic = Critic(sum(state_dims), sum(action_dims)).to(self.device)
            self.actors.append(actor)
            self.critics.append(critic)
            
            actor_target = Actor(state_dims[i], action_dims[i]).to(self.device)
            critic_target = Critic(sum(state_dims), sum(action_dims)).to(self.device)
            actor_target.load_state_dict(actor.state_dict())
            critic_target.load_state_dict(critic.state_dict())
            self.actor_targets.append(actor_target)
            self.critic_targets.append(critic_target)
            
            self.actor_optimizers.append(optim.Adam(actor.parameters(), lr=0.001))
            self.critic_optimizers.append(optim.Adam(critic.parameters(), lr=0.001))
    
    def select_action(self, states):
        actions = []
        for i, actor in enumerate(self.actors):
            state = torch.FloatTensor(states[i]).unsqueeze(0).to(self.device)
            action = actor(state).squeeze(0).cpu().detach().numpy()
            actions.append(action)
        return actions
    
    def update(self, memories):
        # 从每个智能体的记忆中采样
        # 更新critic和actor网络
        pass 