import gymnasium as gym
from gym import spaces
from fmpy import read_model_description, simulate_fmu
import os
import numpy as np

class HVACEnvironment(gym.Env):
    def __init__(self, fmu_path="DC_room302.fmu"):
        super(HVACEnvironment, self).__init__()
        
        # 加载FMU模型
        self.model_description = read_model_description(fmu_path)
        self.fmu_path = fmu_path
        
        # 获取变量引用和名称
        self.input_names = []  # CRAH设定温度名称
        self.output_names = [] # 温度传感器名称
        self.it_load_names = [] # IT负载名称
        
        # 解析模型变量
        for var in self.model_description.modelVariables:
            if var.causality == 'input':
                if 'CRAH' in var.name and 'ST_DAI_NTI' in var.name:
                    self.input_names.append(var.name)
                elif 'P_BCI_NTI' in var.name:
                    self.it_load_names.append(var.name)
            elif var.causality == 'output':
                if 'TH' in var.name:
                    self.output_names.append(var.name)
                elif 'CRAH' in var.name and 'RT_SDO_NTI' in var.name:
                    self.output_names.append(var.name)
        
        # 定义动作空间 (4个CRAH出风温度 + 4个风机转速)
        self.action_space = spaces.Box(
            low=np.array([18.0] * 4 + [0.0] * 4, dtype=np.float32),  # 温度范围
            high=np.array([30.0] * 4 + [1000.0] * 4, dtype=np.float32),  # 风机转速范围
            dtype=np.float32
        )
        
        # 定义观察空间
        self.observation_space = spaces.Box(
            low=-float('inf'),
            high=float('inf'),
            shape=(28 + 16 + 230,),
            dtype=np.float32
        )
        
        # 初始化状态
        self.current_state = None
        self.time = 0.0
        self.reset()

    def reset(self):
        """重置环境"""
        self.time = 0.0
        
        # 设置初始输入
        input_values = {}
        
        # 设置CRAH初始温度
        for name in self.input_names:
            input_values[name] = 22.0  # 初始温度设为22度
            
        # 设置IT负载初始值
        for name in self.it_load_names:
            input_values[name] = np.random.uniform(0, 100)
            
        try:
            # 运行仿真获取初始状态
            result = simulate_fmu(
                self.fmu_path,
                start_time=self.time,
                stop_time=self.time + 1e-6,  # 避免除零问题
                input=input_values,
                output=self.output_names + self.input_names + self.it_load_names
            )
            
            # 保存当前状态
            self.current_state = {name: value[-1] for name, value in zip(result.variable_names, result.values)}
            
        except Exception as e:
            print(f"FMU simulation failed: {str(e)}")
            raise
        
        return self._get_observation()

    def step(self, action):
        """执行一步仿真"""
        # 准备输入
        input_values = {}
        
        # 设置CRAH温度设定值
        for i, name in enumerate(self.input_names[:4]):  # 只取前4个CRAH
            input_values[name] = float(action[i])
        
        # 设置风机转速
        for i, name in enumerate(self.input_names[4:]):  # 取后4个风机转速
            input_values[name] = float(action[i + 4])
        
        # 执行仿真
        stop_time = self.time + 60.0  # 1分钟步长
        result = simulate_fmu(
            self.fmu_path,
            start_time=self.time,
            stop_time=stop_time,
            input=input_values,
            output=self.output_names + self.input_names + self.it_load_names
        )
        
        # 更新时间和状态
        self.time = stop_time
        self.current_state = {name: value[-1] for name, value in zip(result.variable_names, result.values)}
        
        # 获取新的状态
        observation = self._get_observation()
        
        # 计算奖励
        reward = self._calculate_reward(observation, action)
        
        # 判断是否结束
        done = False
        
        return observation, reward, done, {}

    def _get_observation(self):
        """获取环境观察值"""
        # 获取温度传感器数据和CRAH状态
        outputs = [self.current_state[name] for name in self.output_names]
        
        # 获取IT负载数据
        it_loads = [self.current_state[name] for name in self.it_load_names]
        
        # 组合观察值
        observation = np.concatenate([
            np.array(outputs[:28]),  # 温度传感器
            np.array(outputs[28:44]), # CRAH状态
            np.array(it_loads)  # IT负载
        ])
        
        return observation

    def _calculate_reward(self, observation, action):
        """计算奖励"""
        # 目标温度
        target_temp = 22.0
        
        # 获取冷通道温度传感器数据
        cold_channel_temps = observation[:6]  # 假设前6个是冷通道温度传感器
        
        # 计算温度差距
        temp_deviation = np.abs(cold_channel_temps - target_temp)
        
        # 奖励是温度差距的负值，差距越小奖励越高
        reward = -np.mean(temp_deviation)
        
        return reward

    def close(self):
        """关闭环境"""
        pass 