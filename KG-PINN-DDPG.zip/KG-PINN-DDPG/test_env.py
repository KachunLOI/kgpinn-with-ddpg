from hvac_env import HVACEnvironment
import numpy as np
import os
import sys

# 添加当前目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
if current_dir not in sys.path:
    sys.path.append(current_dir)

# FMU文件路径
fmu_file = "DC_room302.fmu"
fmu_path = os.path.join(current_dir, fmu_file)

# 调试信息
print(f"Python路径: {sys.path}")
print(f"当前目录: {current_dir}")
print(f"FMU文件路径: {fmu_path}")
print(f"文件是否存在: {os.path.exists(fmu_path)}")
print(f"文件大小: {os.path.getsize(fmu_path) if os.path.exists(fmu_path) else 'N/A'}")

# 创建环境
env = HVACEnvironment(fmu_path)

# 测试重置
obs = env.reset()
print("Initial observation shape:", obs.shape)
print("First few temperature sensors:", obs[:5])
print("First few CRAH status:", obs[28:33])
print("First few IT loads:", obs[44:49])

# 测试几个步骤
for i in range(5):
    action = np.random.uniform(18.0, 30.0, size=16)
    obs, reward, done, info = env.step(action)
    
    print(f"\nStep {i+1}")
    print(f"Action taken: {action[:3]}...")
    print(f"Reward: {reward}")
    print(f"Average temperature: {np.mean(obs[:28]):.2f}") 